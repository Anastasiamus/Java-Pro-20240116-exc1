package Homework;

public class Main {
    public static void main(String[] args) {
        Person person = new Person();
        Person person1 = new Person("Roman Romanov" , 40);

        person.talk();
        person.move();

        System.out.println();

        person1.move();
        person1.talk();
        
    }
}
